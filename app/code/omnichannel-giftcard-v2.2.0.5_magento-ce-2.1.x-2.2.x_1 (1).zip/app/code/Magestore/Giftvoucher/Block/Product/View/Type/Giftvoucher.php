<?php
/**
 * Copyright © 2017 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magestore\Giftvoucher\Block\Product\View\Type;

/**
 * Class Giftvoucher
 * @package Magestore\Giftvoucher\Block\Product\View\Type
 */
class Giftvoucher extends \Magento\Catalog\Block\Product\View\AbstractView
{

}
