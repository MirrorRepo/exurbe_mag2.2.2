<?php
/**
 * Copyright © 2017 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Created by PhpStorm.
 * User: quocv
 * Date: 27/06/2017
 * Time: 11:29 SA
 */
namespace Magestore\Giftvoucher\Model;

/**
 * Class GiftvoucherProduct
 * @package Magestore\Giftvoucher\Model
 */
class GiftvoucherProduct extends \Magento\Catalog\Model\Product
{

}
