/*
 * Copyright © 2017 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */
define(
    [
        "jquery"
    ], function($){

    window.Giftvoucher = Class.create();
    Giftvoucher.prototype = {
        /**
         * Initialize object
         */
        initialize: function(params) {

        },

        /**
         * Get Package Id
         */


    };

});
