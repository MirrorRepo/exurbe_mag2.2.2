/*
 * Copyright © 2017 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */
/*global define*/
define(
    [
        'jquery',
        'uiComponent'
    ],
    function ($, Component) {
        "use strict";
        return Component.extend({
            initialize: function () {
                console.log('sdfsdafsafdasf');
                this._super();

            }
        });
    }
);
