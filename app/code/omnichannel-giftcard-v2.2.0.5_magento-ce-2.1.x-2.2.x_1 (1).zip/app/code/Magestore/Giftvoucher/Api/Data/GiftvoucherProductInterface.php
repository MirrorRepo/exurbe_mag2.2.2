<?php
/**
 * Copyright © 2017 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magestore\Giftvoucher\Api\Data;

/**
 * CMS block interface.
 * @api
 */
interface GiftvoucherProductInterface extends \Magento\Catalog\Api\Data\ProductInterface
{



}
