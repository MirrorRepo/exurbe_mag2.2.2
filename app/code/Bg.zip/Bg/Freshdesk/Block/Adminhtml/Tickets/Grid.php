<?php

namespace Bg\Freshdesk\Block\Adminhtml\Tickets;

use Bg\Freshdesk\Model\Status;

class Grid extends \Magento\Framework\View\Element\Template
{


   public function getTitle()
    {
        return "Foo Bar Baz";
    }

}
