<?php

namespace Bg\Freshdesk\Block\Widget;

class Freshdesk extends \Magento\Framework\View\Element\Template implements \Magento\Widget\Block\BlockInterface
{
    protected function _construct()
    {
        parent::_construct();
    }
}
