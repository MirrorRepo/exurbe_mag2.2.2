

<!--- Before adding a new issue, please check all closed and existing issues to make sure this is not a duplicate -->


#### Magento version #:

#### Edition (EE, CE, OS, etc):

#### Expected behavior:

#### Actual behavior:

#### Steps to reproduce:

#### Preconditions
<!--- Provide a more detailed information of environment you use -->
<!--- Magento version, tag, HEAD, etc., PHP & MySQL version, etc.. -->


<!--- 
PLEASE NOTE:

We receive multiple emails & support tickets almost daily asking for help. 
In most cases these issues have nothing to do with our extension and mostly 
caused by lack of basic Magento knowledge or not following installation instructions. 

At MagePal, our goal is to develop a wide variety of both free and paid extension 
and due to our limited resources, our main focus are fixing reported bugs and developing 
other great extensions.  

Because of this, we cannot provide free support for our free extensions. 
However, we do offer very affordable support options and/or training. 

For more information visit www.magepal.com or email us at support@magepal.com.
-->
