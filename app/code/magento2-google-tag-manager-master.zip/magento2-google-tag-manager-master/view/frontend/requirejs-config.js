var config = {
    map: {
        '*': {
            magepalGtmDatalayer: 'MagePal_GoogleTagManager/js/datalayer'
        }
    }
};