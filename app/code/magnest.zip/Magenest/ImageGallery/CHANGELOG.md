# Change Log
All notable changes to this extension will be documented in this file.
This extension adheres to [Magenest](http://magenest.com/).

## [1.0.0] - 2017-04-25
### Releases
1. Allow admins to add new images
2. Allow admins to add new gallerys
4. Allow admins to config size image , assign images and gallerys to page
5. Show images and galerrys on frontend page
