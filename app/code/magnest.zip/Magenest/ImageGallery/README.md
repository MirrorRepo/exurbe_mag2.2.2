# README
Thank you for buying our product.
This extension adheres to [Magenest](https://store.magenest.com/).

### User guide
- If you have trouble installing this extension, please visit: http://www.confluence.izysync.com/display/DOC/1.+Image+Gallery+Installation+Guide
- For detailed user guide of this extension, please visit: http://www.confluence.izysync.com/display/DOC/2.+Image+Gallery+User+Guide
- All the updates of this module are included in CHANGELOG.md file.

Support portal : http://servicedesk.izysync.com/servicedesk/customer/portal/118