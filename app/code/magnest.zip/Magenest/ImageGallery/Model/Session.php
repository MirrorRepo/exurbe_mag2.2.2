<?php

namespace Magenest\ImageGallery\Model;

class Session extends \Magento\Framework\Session\SessionManager
{

}

?>